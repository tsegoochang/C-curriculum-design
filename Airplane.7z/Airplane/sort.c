#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data.h"
#include <time.h>
#define wronghint\
    if(i==1)printf("\t���벻ҪΪ��\n");\
	if(i==2)printf("\t������ϵͳ�ܶ�ȡ�ĺϷ��ַ�\n");
#define adminsorttext\
    printf("\t     ****������Ϣ����****\n\t****��ѡ�񼴽����е��������������****\n");\
	printf("\t\t0.�˳�ϵͳ\n\t\t1.���պ������ʱ������\n\t\t2.���ջ�Ʊ�۸���������\n\t\t3.���ջ�Ʊ�۸�������\n\t\t4.���պ��������\n\t\t5.������һ��\n");\
    printf("\t��������������Ҫ���еĲ��������:\n");
void Adminsort(user* userlist,user* adminlist,airplane* airplanelist[],user* admin){//301����δ��ɵ�ԭ������   181������һ���˵�����
	void Airsort_1(user* userlist,user* adminlist,airplane* airplanelist[],user* admin);
	void Airsort_2(user* userlist,user* adminlist,airplane* airplanelist[],user* admin);
	void Airsort_3(user* userlist,user* adminlist,airplane* airplanelist[],user* admin);
    void Airsort_4(user* userlist,user* adminlist,airplane* airplanelist[],user* admin);
    fflush(stdin);
    system("cls");
    adminsorttext
    int i=0;
	char a[3];
	fflush(stdin);
	while(fgets(a,3,stdin)){
	if(a[0]==10){
		i=1;
		fflush(stdin);
	}
	else if(a[0]<'0'||a[0]>'5'||a[1]!='\n'){
		i=2;
		fflush(stdin);
	}
	else
    {
		switch(a[0])
    {
		case '0':
			Exit(userlist,adminlist,airplanelist);break;
		case '1':
			Airsort_1(userlist,adminlist,airplanelist,admin);break;
		case '2':
			Airsort_2(userlist,adminlist,airplanelist,admin);break;
		case '3':
		    Airsort_3(userlist,adminlist,airplanelist,admin);break;
        case '4':
		    Airsort_4(userlist,adminlist,airplanelist,admin);break;
		case '5':
		    Admin_3(userlist,adminlist,airplanelist,admin);break;
	}
	}
	fflush(stdin);
	system("cls");
	adminsorttext
	wronghint
	}
}
void Airsort_1(user* userlist,user* adminlist,airplane* airplanelist[],user* admin){
	printf("���պ������ʱ������\n");
	 int k,i,j,max,x,y,z;
	 airplane* a;
	 airplane* b;
	 airplane* c;
	 airplane* d;
	 airplane* e;
	 	for(i=0,a=airplanelist[0];;i++){
	 		if(a==NULL){
	 			break;
			 }
			 a=a->next;
		 }
	 max=i-1;
	 for(k=0;k<7;k++){
          for(j=0;j<max-1;j++){
          	for(i=0,a=airplanelist[k]->next,e=airplanelist[k];i<max-1-j;i++,a=a->next,e=e->next){
          		b=a->next;
          		if(b==NULL)break;
          		for(z=0,x=0;a->begintime[z]!='\0';z++){
          			if(a->begintime[z]!=':'){
          				x=x*10+a->begintime[z];
					  }
					  else continue;
				  }
          		for(z=0,y=0;b->begintime[z]!='\0';z++){
          			if(b->begintime[z]!=':'){
          				y=y*10+b->begintime[z];
					  }
					  else continue;
				  }
          		if(x>y){
          			c=createnode(a->num,a->begin,a->end,a->begintime,a->endtime,a->maxpeople,a->tempeople,a->price);
          			d=createnode(b->num,b->begin,b->end,b->begintime,b->endtime,b->maxpeople,b->tempeople,b->price);
          			e->next=d;
          			d->next=c;
          			c->next=b->next;
          			free(a);
          			free(b);
          			a=d;
          			b=c;
				  }
			  }
		  }
}
    saveairplane("airplane0.txt",airplanelist[0]);
    saveairplane("airplane1.txt",airplanelist[1]);
    saveairplane("airplane2.txt",airplanelist[2]);
    saveairplane("airplane3.txt",airplanelist[3]);
    saveairplane("airplane4.txt",airplanelist[4]);
    saveairplane("airplane5.txt",airplanelist[5]);
    saveairplane("airplane6.txt",airplanelist[6]);
    printf("�������\n");
    system("pause");
    system("cls");
    Adminsort(userlist,adminlist,airplanelist,admin);
}
void Airsort_2(user* userlist,user* adminlist,airplane* airplanelist[],user* admin){
     	printf("���պ���Ʊ����������\n");
	 int k,i,j,max,x,y,z;
	 airplane* a;
	 airplane* b;
	 airplane* c;
	 airplane* d;
	 airplane* e;
	 	for(i=0,a=airplanelist[0];;i++){
	 		if(a==NULL){
	 			break;
			 }
			 a=a->next;
		 }
	 max=i-1;
	 for(k=0;k<7;k++){
          for(j=0;j<max-1;j++){
          	for(i=0,a=airplanelist[k]->next,e=airplanelist[k];i<max-1-j;i++,a=a->next,e=e->next){
          		b=a->next;
          		if(b==NULL)break;
          		if(a->price>b->price){
          			c=createnode(a->num,a->begin,a->end,a->begintime,a->endtime,a->maxpeople,a->tempeople,a->price);
          			d=createnode(b->num,b->begin,b->end,b->begintime,b->endtime,b->maxpeople,b->tempeople,b->price);
          			e->next=d;
          			d->next=c;
          			c->next=b->next;
          			free(a);
          			free(b);
          			a=d;
          			b=c;
				  }
			  }
		  }
}
    saveairplane("airplane0.txt",airplanelist[0]);
    saveairplane("airplane1.txt",airplanelist[1]);
    saveairplane("airplane2.txt",airplanelist[2]);
    saveairplane("airplane3.txt",airplanelist[3]);
    saveairplane("airplane4.txt",airplanelist[4]);
    saveairplane("airplane5.txt",airplanelist[5]);
    saveairplane("airplane6.txt",airplanelist[6]);
    printf("�������\n");
    system("pause");
    system("cls");
    Adminsort(userlist,adminlist,airplanelist,admin);
}
void Airsort_3(user* userlist,user* adminlist,airplane* airplanelist[],user* admin){
     	printf("���պ���Ʊ�۽�������\n");
	 int k,i,j,max,x,y,z;
	 airplane* a;
	 airplane* b;
	 airplane* c;
	 airplane* d;
	 airplane* e;
	 	for(i=0,a=airplanelist[0];;i++){
	 		if(a==NULL){
	 			break;
			 }
			 a=a->next;
		 }
	 max=i-1;
	 for(k=0;k<7;k++){
          for(j=0;j<max-1;j++){
          	for(i=0,a=airplanelist[k]->next,e=airplanelist[k];i<max-1-j;i++,a=a->next,e=e->next){
          		b=a->next;
          		if(b==NULL)break;
          		if(a->price<b->price){
          			c=createnode(a->num,a->begin,a->end,a->begintime,a->endtime,a->maxpeople,a->tempeople,a->price);
          			d=createnode(b->num,b->begin,b->end,b->begintime,b->endtime,b->maxpeople,b->tempeople,b->price);
          			e->next=d;
          			d->next=c;
          			c->next=b->next;
          			free(a);
          			free(b);
          			a=d;
          			b=c;
				  }
			  }
		  }
}
    saveairplane("airplane0.txt",airplanelist[0]);
    saveairplane("airplane1.txt",airplanelist[1]);
    saveairplane("airplane2.txt",airplanelist[2]);
    saveairplane("airplane3.txt",airplanelist[3]);
    saveairplane("airplane4.txt",airplanelist[4]);
    saveairplane("airplane5.txt",airplanelist[5]);
    saveairplane("airplane6.txt",airplanelist[6]);
    printf("�������\n");
    system("pause");
    system("cls");
    Adminsort(userlist,adminlist,airplanelist,admin);
}
void Airsort_4(user* userlist,user* adminlist,airplane* airplanelist[],user* admin){
	printf("���պ��������\n");
	 int k,i,j,max,x,y,z;
	 airplane* a;
	 airplane* b;
	 airplane* c;
	 airplane* d;
	 airplane* e;
	 	for(i=0,a=airplanelist[0];;i++){
	 		if(a==NULL){
	 			break;
			 }
			 a=a->next;
		 }
	 max=i-1;
	 for(k=0;k<7;k++){
          for(j=0;j<max-1;j++){
          	for(i=0,a=airplanelist[k]->next,e=airplanelist[k];i<max-1-j;i++,a=a->next,e=e->next){
          		b=a->next;
          		if(b==NULL)break;
          		for(z=0,x=0;a->num[z]!='\0';z++){
          			if(a->num[z]!=':'){
          				x=x*10+a->num[z];
					  }
					  else continue;
				  }
          		for(z=0,y=0;b->num[z]!='\0';z++){
          			if(b->num[z]!=':'){
          				y=y*10+b->num[z];
					  }
					  else continue;
				  }
          		if(x>y){
          			c=createnode(a->num,a->begin,a->end,a->begintime,a->endtime,a->maxpeople,a->tempeople,a->price);
          			d=createnode(b->num,b->begin,b->end,b->begintime,b->endtime,b->maxpeople,b->tempeople,b->price);
          			e->next=d;
          			d->next=c;
          			c->next=b->next;
          			free(a);
          			free(b);
          			a=d;
          			b=c;
				  }
			  }
		  }
}
    saveairplane("airplane0.txt",airplanelist[0]);
    saveairplane("airplane1.txt",airplanelist[1]);
    saveairplane("airplane2.txt",airplanelist[2]);
    saveairplane("airplane3.txt",airplanelist[3]);
    saveairplane("airplane4.txt",airplanelist[4]);
    saveairplane("airplane5.txt",airplanelist[5]);
    saveairplane("airplane6.txt",airplanelist[6]);
    printf("�������\n");
    system("pause");
    system("cls");
    Adminsort(userlist,adminlist,airplanelist,admin);
}
